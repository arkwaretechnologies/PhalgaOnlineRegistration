import RegistrationForm from '@/components/RegistrationForm';

export default function Home() {
  return <RegistrationForm />;
}

