/** @type {import('next').NextConfig} */
const nextConfig = {
  output: 'standalone', // Optimizes for server deployment
}

module.exports = nextConfig

