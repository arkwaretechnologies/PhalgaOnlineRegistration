# Public Assets Directory

## Logo Files

Place your PHALGA logo image files here:

- **`left.png`** - Logo for the left side of the header
- **`right.png`** - Logo for the right side of the header

### Logo Specifications:
- Recommended height: 96 pixels (h-24)
- Width: Auto (maintains aspect ratio)
- Supported formats: PNG, JPG, SVG
- Logos will automatically hide if files are not found

The logos will appear on either side of the "PHALGA Registration Form" title in the header.

